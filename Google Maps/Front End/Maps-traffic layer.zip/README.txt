Unzip the folder
Everything must be in the same folder for it to work.
Double click the "index.html" file. It should open the website in your default browser.