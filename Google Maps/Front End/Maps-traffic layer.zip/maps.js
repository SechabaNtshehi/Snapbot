let map;

var lat = 0;
var lng = 0;

async function initMap() {
	// console.log()
  const { Map } = await google.maps.importLibrary("maps");

  map = new Map(document.getElementById("map"), {
    center: { lat: parseFloat(lat), lng:    parseFloat(lng)},
    zoom: 90,
  });

  const trafficLayer = new google.maps.TrafficLayer();

  trafficLayer.setMap(map);
}

initMap(); 

document.querySelector("form").addEventListener("submit", (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  

  lat = data.lat;
  lng = data.lng;

  console.log(typeof lat + "--" + typeof lng);
  initMap();
});

function loadMap(){
  console.log(document.getElementById("lat").value);
  initMap();  
}


// function initMap() {
//   const map = new google.maps.Map(document.getElementById("map"), {
//     zoom: 13,
//     center: { lat: 34.04924594193164, lng: -118.24104309082031 },
//   });
//   const trafficLayer = new google.maps.TrafficLayer();

//   trafficLayer.setMap(map);
// }

// window.initMap = initMap;
